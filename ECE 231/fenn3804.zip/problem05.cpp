#include "StdAfx.h"
//#define _USE_MATH_DEFINES
//#include <cmath>
#include <iostream>
#include <iomanip>   // For output formatting
#include <cmath>     // For M_PI

using namespace std;


int main()
{
    // M_PI should be printed out to 8 digits after the decimal point
    // Add an output manipulator to do that.
    cout << setprecision (9) << M_PI << endl;// Added the setprecision (9) output manipulator

    return 0;
}

