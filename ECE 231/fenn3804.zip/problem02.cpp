//#include "StdAfx.h"



class Myclass
{
public: //Added public:
    int age;
    float BMI;
};

int main()
{
    Myclass m;

    // The next line produces a compiler error; add one line of code to the
    // declaration of Myclass to resolve this problem.  (Note that no
    // #include is needed.)

    m.age = 37;

    return 0;
}
