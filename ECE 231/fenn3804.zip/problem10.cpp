//#include "StdAfx.h"
#include <iostream>
#include <string>
using namespace std;

class Simple
{
   	protected:  // So Simon can see name
    string name;

    public:
    virtual void setName (const string newName) { name = newName; } //added virutal member
    virtual void sayHi(); //added virtual member
	
	
};

class Simon : public Simple
{
    public:
    void sayHi();
	
};

void Simple::sayHi()
{
    cout << "I'm " << name << " Simple." << endl;
}

void Simon::sayHi()
{
    cout << "I'm " << name << " Simon." << endl;
}

void greet(Simple* s)
{
    s->sayHi();
}

int main()
{
    Simon  simon;
    Simple simple;

    simon.setName("Simon");
    simple.setName("Simple");

    // At this point, the program should print
    // I'm Simon Simon
    // I'm Simple Simple"
    // Clearly the attempt to override the sayHi() function is not working
    // Change the Simple class to allow Simon to override the sayHi() function
    greet(&simon);
    greet(&simple);

    return 0;
}

