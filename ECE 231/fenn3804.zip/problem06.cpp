//#include "StdAfx.h"
#include <iostream>
#include <iomanip>   // For output formatting
#include <cmath>     // For M_PI
using namespace std;

class General
{
    int x;

    public:
    int getX() { return x; }
    void setX(int newX) { x = newX; }
};

// Complete the class "Specific" that extends General by adding 
// a data member y with similar behavior to General's 'x'.  
// The main() function below should print
// s = (3, 4)

class Specific : public General
{
    int y;  //extended General by adding the 'y' data member

	public: //Replicated similar behavior
    int getY() { return y; }
    void setY(int newY) { y = newY; }
};

int main()
{
    Specific s;
    s.setX(3);
    s.setY(4);
    cout << "s = (" << s.getX() << ", " << s.getY() << ")" << endl;
    return 0;
}

