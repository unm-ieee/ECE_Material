//#include "StdAfx.h"
#include <iostream>
#include <iomanip>  // For setw() function

// This program is commented for your help.  See the comment below
// beginning "PROBLEM" for your assignment.

using namespace std;

class Matrix
{
    int rows;
    int cols;
    int *data;

    public:
    // Constructor with the number of rows and columns specified
    // No "default constructor" is needed in this example
    Matrix(int r, int c);
    // Destructor
    ~Matrix();
    // Get the number of rows or columns
    int   getRows();
    int   getCols();
    // Get and set the data at the specified row and column
    int   getData(int row, int col);
    void  setData(int row, int col, int n);
};

// Constructor: set member data and allocate memory for data
// Ignore the error condition where either r or c are negative or enormous
Matrix::Matrix(int r, int c)
{
    // Set the row/column values
    rows = r;
    cols = c;
    // Allocate an array to hold the data; error checking comes later
    data = new int[rows*cols];
}

// Destructor
Matrix::~Matrix()
{
    // Since data was created as an array, it must be deleted as an array
    delete[] data;
}

int Matrix::getRows()
{
    return rows;
}

int Matrix::getCols()
{
    return cols;
}

void Matrix::setData(int row, int col, int n)
{
    // The location of a datum is given by the row index times the
    // number of columns plus the column index.  This is called
    // "row major ordering".
    data[row*cols + col] = n;
}

int Matrix::getData(int row, int col)
{
    return data[row*cols + col];
}

int main()
{
    const int Rows = 2;
    const int Cols = 3;
    int   fakeData = 1;

    // Here we create a matrix and fill it with sequential data
    Matrix m(Rows, Cols);
    for (int i = 0; i < Rows; i++)
        for (int j = 0; j < Cols; j++)
        m.setData(i, j, fakeData++);

    // PROBLEM:
    // Here we print it, but it's not right; fix the error in
    // the nested for loop.
    // The correct result is:
    // 1   2   3
    // 4   5   6
    cout << endl;
    for (int i = 0; i < Rows; ++i)
    {
        for (int j = 0; j < Cols; j++)
            cout << setw(4) << m.getData(i, j); //(j, i) were in the wrong order
        cout << endl;
    }

    return 0;
}

