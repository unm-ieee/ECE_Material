//#include "StdAfx.h"
#include <iostream>

using namespace std;

class Simple
{
    int x;
    int y;

    public:
    Simple();
    Simple(int xValue, int yValue);
    int getX() { return x; }
    int getY() { return y; }
};

// Complete the constructors so that the default constructor "Simple()"
// initializes both members to 0 and the other constructor 
// "Simple(int xValue, int yValue)" initializes them to the values passed.

Simple::Simple()
	: x(0), y(0) //added initial values
{

}

Simple::Simple(int xValue, int yValue)
	: x(xValue), y(yValue) //added passed values
{
}


int main()
{
    // With the following initialization, the program should output the
    // following lines:
    //   V1 = 0, 0
    //   V2 = 5, 6

    Simple V1;
    Simple V2(5, 6);
    cout << "V1 = " << V1.getX() << ", " << V1.getY() << endl;
    cout << "V2 = " << V2.getX() << ", " << V2.getY() << endl;
    return 0;
}

