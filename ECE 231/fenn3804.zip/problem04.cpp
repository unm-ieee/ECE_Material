//#include "StdAfx.h"
#include <iostream>
#include <cmath>  // For the sqrt function
using namespace std;

// This program should print "Length of a = 5", but instead prints
// "Length of a = " followed by some strange value.  Find and fix the
// problem.  Only one line of code must be changed.

class Vector
{
    float x;
    float y;

    public:
    // The following accessors use "inline" code; it's okay
    float getX()         { return x; }
    void  setX(float xx) { x = xx; }
    float getY()         { return y; }
    void  setY(float yy) { y = yy; }
    float length();
};

// This function calculates the length of the hypotenuse of the right
// triangle whose sides are x and y; it's incorrect.
float Vector::length()
{
    return sqrt (pow(x,2) +  pow(y,2)); //added the pow function
}

int main()
{
    Vector a;
    a.setX(3.0);
    a.setY(4.0);
    cout << "Length of a = " << a.length() << endl;
    
    return 0;
}

