//#include "StdAfx.h"


class Myclass
{
    int age;
    float BMI;

    public:

    int getAge();
    void setAge(int a);
};

// The accessor functions getAge() and setAge() both produce compiler
// errors.  Fix them (two lines must be changed).
int Myclass::getAge() //Added Myclass class
{
    return age;
}

void Myclass::setAge(int a) //Added Myclass class
{
    age = a;
}

int main()
{
    Myclass m;

    m.getAge();

    return 0;
}
