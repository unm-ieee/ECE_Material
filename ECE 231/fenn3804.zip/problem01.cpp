//#include "StdAfx.h"
#include <iostream>
using namespace std; //Added using namespace std
int main()
{
    // The line below produces errors.  Add one line of code above 
    // "int main()" that will resolve this problem.
    
    cout << "Welcome to C++!" << endl;

    return 0;
}
