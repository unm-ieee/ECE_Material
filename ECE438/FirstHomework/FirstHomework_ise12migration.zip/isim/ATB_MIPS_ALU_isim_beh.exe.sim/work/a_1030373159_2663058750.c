/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0xc3576ebc */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "D:/ECE.CLASSES/ECE438/FirstHomework/LACUnit.vhd";
extern char *IEEE_P_2592010699;

unsigned char ieee_p_2592010699_sub_1605435078_503743352(char *, unsigned char , unsigned char );
unsigned char ieee_p_2592010699_sub_2545490612_503743352(char *, unsigned char , unsigned char );


static void work_a_1030373159_2663058750_p_0(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    int64 t8;
    unsigned char t9;
    unsigned char t10;
    unsigned char t11;
    unsigned char t12;
    char *t13;
    char *t14;
    char *t15;

LAB0:    xsi_set_current_line(40, ng0);
    t1 = (t0 + 2312U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 5640);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = t3;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(41, ng0);
    t8 = (2 * 1000LL);
    t1 = (t0 + 1192U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 1032U);
    t4 = *((char **)t1);
    t9 = *((unsigned char *)t4);
    t1 = (t0 + 2472U);
    t5 = *((char **)t1);
    t10 = *((unsigned char *)t5);
    t11 = ieee_p_2592010699_sub_1605435078_503743352(IEEE_P_2592010699, t9, t10);
    t12 = ieee_p_2592010699_sub_2545490612_503743352(IEEE_P_2592010699, t3, t11);
    t1 = (t0 + 5704);
    t6 = (t1 + 56U);
    t7 = *((char **)t6);
    t13 = (t7 + 56U);
    t14 = *((char **)t13);
    *((unsigned char *)t14) = t12;
    xsi_driver_first_trans_delta(t1, 0U, 1, t8);
    t15 = (t0 + 5704);
    xsi_driver_intertial_reject(t15, t8, t8);
    xsi_set_current_line(42, ng0);
    t8 = (2 * 1000LL);
    t1 = (t0 + 1512U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 1352U);
    t4 = *((char **)t1);
    t9 = *((unsigned char *)t4);
    t1 = (t0 + 2632U);
    t5 = *((char **)t1);
    t10 = *((unsigned char *)t5);
    t11 = ieee_p_2592010699_sub_1605435078_503743352(IEEE_P_2592010699, t9, t10);
    t12 = ieee_p_2592010699_sub_2545490612_503743352(IEEE_P_2592010699, t3, t11);
    t1 = (t0 + 5768);
    t6 = (t1 + 56U);
    t7 = *((char **)t6);
    t13 = (t7 + 56U);
    t14 = *((char **)t13);
    *((unsigned char *)t14) = t12;
    xsi_driver_first_trans_delta(t1, 0U, 1, t8);
    t15 = (t0 + 5768);
    xsi_driver_intertial_reject(t15, t8, t8);
    xsi_set_current_line(43, ng0);
    t8 = (2 * 1000LL);
    t1 = (t0 + 1832U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 1672U);
    t4 = *((char **)t1);
    t9 = *((unsigned char *)t4);
    t1 = (t0 + 2792U);
    t5 = *((char **)t1);
    t10 = *((unsigned char *)t5);
    t11 = ieee_p_2592010699_sub_1605435078_503743352(IEEE_P_2592010699, t9, t10);
    t12 = ieee_p_2592010699_sub_2545490612_503743352(IEEE_P_2592010699, t3, t11);
    t1 = (t0 + 5832);
    t6 = (t1 + 56U);
    t7 = *((char **)t6);
    t13 = (t7 + 56U);
    t14 = *((char **)t13);
    *((unsigned char *)t14) = t12;
    xsi_driver_first_trans_delta(t1, 0U, 1, t8);
    t15 = (t0 + 5832);
    xsi_driver_intertial_reject(t15, t8, t8);
    xsi_set_current_line(44, ng0);
    t8 = (2 * 1000LL);
    t1 = (t0 + 2152U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 1992U);
    t4 = *((char **)t1);
    t9 = *((unsigned char *)t4);
    t1 = (t0 + 2952U);
    t5 = *((char **)t1);
    t10 = *((unsigned char *)t5);
    t11 = ieee_p_2592010699_sub_1605435078_503743352(IEEE_P_2592010699, t9, t10);
    t12 = ieee_p_2592010699_sub_2545490612_503743352(IEEE_P_2592010699, t3, t11);
    t1 = (t0 + 5896);
    t6 = (t1 + 56U);
    t7 = *((char **)t6);
    t13 = (t7 + 56U);
    t14 = *((char **)t13);
    *((unsigned char *)t14) = t12;
    xsi_driver_first_trans_delta(t1, 0U, 1, t8);
    t15 = (t0 + 5896);
    xsi_driver_intertial_reject(t15, t8, t8);
    t1 = (t0 + 5528);
    *((int *)t1) = 1;

LAB1:    return;
}

static void work_a_1030373159_2663058750_p_1(char *t0)
{
    int64 t1;
    char *t2;
    char *t3;
    unsigned char t4;
    char *t5;
    unsigned char t6;
    unsigned char t7;
    char *t8;
    unsigned char t9;
    unsigned char t10;
    char *t11;
    unsigned char t12;
    unsigned char t13;
    char *t14;
    char *t15;
    char *t16;
    char *t17;
    char *t18;
    char *t19;

LAB0:    xsi_set_current_line(47, ng0);

LAB3:    t1 = (3 * 1000LL);
    t2 = (t0 + 1992U);
    t3 = *((char **)t2);
    t4 = *((unsigned char *)t3);
    t2 = (t0 + 1672U);
    t5 = *((char **)t2);
    t6 = *((unsigned char *)t5);
    t7 = ieee_p_2592010699_sub_1605435078_503743352(IEEE_P_2592010699, t4, t6);
    t2 = (t0 + 1352U);
    t8 = *((char **)t2);
    t9 = *((unsigned char *)t8);
    t10 = ieee_p_2592010699_sub_1605435078_503743352(IEEE_P_2592010699, t7, t9);
    t2 = (t0 + 1032U);
    t11 = *((char **)t2);
    t12 = *((unsigned char *)t11);
    t13 = ieee_p_2592010699_sub_1605435078_503743352(IEEE_P_2592010699, t10, t12);
    t2 = (t0 + 5960);
    t14 = (t2 + 56U);
    t15 = *((char **)t14);
    t16 = (t15 + 56U);
    t17 = *((char **)t16);
    *((unsigned char *)t17) = t13;
    xsi_driver_first_trans_delta(t2, 0U, 1, t1);
    t18 = (t0 + 5960);
    xsi_driver_intertial_reject(t18, t1, t1);

LAB2:    t19 = (t0 + 5544);
    *((int *)t19) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_1030373159_2663058750_p_2(char *t0)
{
    int64 t1;
    char *t2;
    char *t3;
    unsigned char t4;
    char *t5;
    unsigned char t6;
    char *t7;
    unsigned char t8;
    unsigned char t9;
    unsigned char t10;
    char *t11;
    unsigned char t12;
    char *t13;
    unsigned char t14;
    unsigned char t15;
    char *t16;
    unsigned char t17;
    unsigned char t18;
    unsigned char t19;
    char *t20;
    unsigned char t21;
    char *t22;
    unsigned char t23;
    unsigned char t24;
    char *t25;
    unsigned char t26;
    unsigned char t27;
    char *t28;
    unsigned char t29;
    unsigned char t30;
    unsigned char t31;
    char *t32;
    char *t33;
    char *t34;
    char *t35;
    char *t36;
    char *t37;

LAB0:    xsi_set_current_line(49, ng0);

LAB3:    t1 = (9 * 1000LL);
    t2 = (t0 + 2152U);
    t3 = *((char **)t2);
    t4 = *((unsigned char *)t3);
    t2 = (t0 + 1992U);
    t5 = *((char **)t2);
    t6 = *((unsigned char *)t5);
    t2 = (t0 + 1832U);
    t7 = *((char **)t2);
    t8 = *((unsigned char *)t7);
    t9 = ieee_p_2592010699_sub_1605435078_503743352(IEEE_P_2592010699, t6, t8);
    t10 = ieee_p_2592010699_sub_2545490612_503743352(IEEE_P_2592010699, t4, t9);
    t2 = (t0 + 1992U);
    t11 = *((char **)t2);
    t12 = *((unsigned char *)t11);
    t2 = (t0 + 1672U);
    t13 = *((char **)t2);
    t14 = *((unsigned char *)t13);
    t15 = ieee_p_2592010699_sub_1605435078_503743352(IEEE_P_2592010699, t12, t14);
    t2 = (t0 + 1512U);
    t16 = *((char **)t2);
    t17 = *((unsigned char *)t16);
    t18 = ieee_p_2592010699_sub_1605435078_503743352(IEEE_P_2592010699, t15, t17);
    t19 = ieee_p_2592010699_sub_2545490612_503743352(IEEE_P_2592010699, t10, t18);
    t2 = (t0 + 1992U);
    t20 = *((char **)t2);
    t21 = *((unsigned char *)t20);
    t2 = (t0 + 1672U);
    t22 = *((char **)t2);
    t23 = *((unsigned char *)t22);
    t24 = ieee_p_2592010699_sub_1605435078_503743352(IEEE_P_2592010699, t21, t23);
    t2 = (t0 + 1352U);
    t25 = *((char **)t2);
    t26 = *((unsigned char *)t25);
    t27 = ieee_p_2592010699_sub_1605435078_503743352(IEEE_P_2592010699, t24, t26);
    t2 = (t0 + 1192U);
    t28 = *((char **)t2);
    t29 = *((unsigned char *)t28);
    t30 = ieee_p_2592010699_sub_1605435078_503743352(IEEE_P_2592010699, t27, t29);
    t31 = ieee_p_2592010699_sub_2545490612_503743352(IEEE_P_2592010699, t19, t30);
    t2 = (t0 + 6024);
    t32 = (t2 + 56U);
    t33 = *((char **)t32);
    t34 = (t33 + 56U);
    t35 = *((char **)t34);
    *((unsigned char *)t35) = t31;
    xsi_driver_first_trans_delta(t2, 0U, 1, t1);
    t36 = (t0 + 6024);
    xsi_driver_intertial_reject(t36, t1, t1);

LAB2:    t37 = (t0 + 5560);
    *((int *)t37) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}


extern void work_a_1030373159_2663058750_init()
{
	static char *pe[] = {(void *)work_a_1030373159_2663058750_p_0,(void *)work_a_1030373159_2663058750_p_1,(void *)work_a_1030373159_2663058750_p_2};
	xsi_register_didat("work_a_1030373159_2663058750", "isim/ATB_MIPS_ALU_isim_beh.exe.sim/work/a_1030373159_2663058750.didat");
	xsi_register_executes(pe);
}
