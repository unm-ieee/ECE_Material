/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0xc3576ebc */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "F:/ECE.CLASSES/ECE 443/Screeen/SCRN.vhd";
extern char *IEEE_P_2592010699;
extern char *IEEE_P_1242562249;

char *ieee_p_1242562249_sub_1547198987_1035706684(char *, char *, char *, char *, char *, char *);
unsigned char ieee_p_2592010699_sub_1744673427_503743352(char *, char *, unsigned int , unsigned int );


static void work_a_0197255140_3212880686_p_0(char *t0)
{
    char t3[16];
    char t8[16];
    char *t1;
    unsigned char t2;
    char *t4;
    char *t5;
    char *t6;
    char *t9;
    char *t10;
    int t11;
    unsigned int t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    char *t17;

LAB0:    xsi_set_current_line(32, ng0);
    t1 = (t0 + 992U);
    t2 = ieee_p_2592010699_sub_1744673427_503743352(IEEE_P_2592010699, t1, 0U, 0U);
    if (t2 != 0)
        goto LAB2;

LAB4:
LAB3:    t1 = (t0 + 5352);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(33, ng0);
    t4 = (t0 + 1832U);
    t5 = *((char **)t4);
    t4 = (t0 + 8636U);
    t6 = (t0 + 3368742);
    t9 = (t8 + 0U);
    t10 = (t9 + 0U);
    *((int *)t10) = 0;
    t10 = (t9 + 4U);
    *((int *)t10) = 2;
    t10 = (t9 + 8U);
    *((int *)t10) = 1;
    t11 = (2 - 0);
    t12 = (t11 * 1);
    t12 = (t12 + 1);
    t10 = (t9 + 12U);
    *((unsigned int *)t10) = t12;
    t10 = ieee_p_1242562249_sub_1547198987_1035706684(IEEE_P_1242562249, t3, t5, t4, t6, t8);
    t13 = (t0 + 5512);
    t14 = (t13 + 56U);
    t15 = *((char **)t14);
    t16 = (t15 + 56U);
    t17 = *((char **)t16);
    memcpy(t17, t10, 3U);
    xsi_driver_first_trans_fast(t13);
    goto LAB3;

}

static void work_a_0197255140_3212880686_p_1(char *t0)
{
    char t7[16];
    char t12[16];
    char *t1;
    int t2;
    unsigned int t3;
    unsigned int t4;
    unsigned int t5;
    unsigned char t6;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t13;
    char *t14;
    int t15;
    unsigned int t16;
    char *t17;
    char *t18;
    char *t19;
    char *t20;
    char *t21;

LAB0:    xsi_set_current_line(40, ng0);
    t1 = (t0 + 1792U);
    t2 = (2 - 2);
    t3 = (t2 * -1);
    t4 = (1U * t3);
    t5 = (0 + t4);
    t6 = ieee_p_2592010699_sub_1744673427_503743352(IEEE_P_2592010699, t1, 0U, t5);
    if (t6 != 0)
        goto LAB2;

LAB4:
LAB3:    t1 = (t0 + 5368);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(41, ng0);
    t8 = (t0 + 2472U);
    t9 = *((char **)t8);
    t8 = (t0 + 8668U);
    t10 = (t0 + 3368745);
    t13 = (t12 + 0U);
    t14 = (t13 + 0U);
    *((int *)t14) = 0;
    t14 = (t13 + 4U);
    *((int *)t14) = 9;
    t14 = (t13 + 8U);
    *((int *)t14) = 1;
    t15 = (9 - 0);
    t16 = (t15 * 1);
    t16 = (t16 + 1);
    t14 = (t13 + 12U);
    *((unsigned int *)t14) = t16;
    t14 = ieee_p_1242562249_sub_1547198987_1035706684(IEEE_P_1242562249, t7, t9, t8, t10, t12);
    t17 = (t0 + 5576);
    t18 = (t17 + 56U);
    t19 = *((char **)t18);
    t20 = (t19 + 56U);
    t21 = *((char **)t20);
    memcpy(t21, t14, 10U);
    xsi_driver_first_trans_fast(t17);
    xsi_set_current_line(42, ng0);
    t1 = (t0 + 2472U);
    t8 = *((char **)t1);
    t1 = (t0 + 3368755);
    t6 = 1;
    if (10U == 10U)
        goto LAB8;

LAB9:    t6 = 0;

LAB10:    if (t6 != 0)
        goto LAB5;

LAB7:
LAB6:    goto LAB3;

LAB5:    xsi_set_current_line(43, ng0);
    t13 = (t0 + 3368765);
    t17 = (t0 + 5576);
    t18 = (t17 + 56U);
    t19 = *((char **)t18);
    t20 = (t19 + 56U);
    t21 = *((char **)t20);
    memcpy(t21, t13, 10U);
    xsi_driver_first_trans_fast(t17);
    xsi_set_current_line(44, ng0);
    t1 = (t0 + 2632U);
    t8 = *((char **)t1);
    t1 = (t0 + 8684U);
    t9 = (t0 + 3368775);
    t11 = (t12 + 0U);
    t13 = (t11 + 0U);
    *((int *)t13) = 0;
    t13 = (t11 + 4U);
    *((int *)t13) = 9;
    t13 = (t11 + 8U);
    *((int *)t13) = 1;
    t2 = (9 - 0);
    t3 = (t2 * 1);
    t3 = (t3 + 1);
    t13 = (t11 + 12U);
    *((unsigned int *)t13) = t3;
    t13 = ieee_p_1242562249_sub_1547198987_1035706684(IEEE_P_1242562249, t7, t8, t1, t9, t12);
    t14 = (t0 + 5640);
    t17 = (t14 + 56U);
    t18 = *((char **)t17);
    t19 = (t18 + 56U);
    t20 = *((char **)t19);
    memcpy(t20, t13, 10U);
    xsi_driver_first_trans_fast(t14);
    goto LAB6;

LAB8:    t3 = 0;

LAB11:    if (t3 < 10U)
        goto LAB12;
    else
        goto LAB10;

LAB12:    t10 = (t8 + t3);
    t11 = (t1 + t3);
    if (*((unsigned char *)t10) != *((unsigned char *)t11))
        goto LAB9;

LAB13:    t3 = (t3 + 1);
    goto LAB11;

}

static void work_a_0197255140_3212880686_p_2(char *t0)
{
    unsigned char t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    unsigned char t6;
    unsigned char t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    unsigned char t12;
    char *t13;
    char *t14;
    char *t16;
    unsigned char t17;
    char *t18;
    char *t19;
    char *t20;
    char *t21;
    char *t22;

LAB0:    xsi_set_current_line(52, ng0);
    t2 = (t0 + 2472U);
    t3 = *((char **)t2);
    t2 = (t0 + 3368785);
    t5 = ((IEEE_P_2592010699) + 4024);
    t6 = xsi_vhdl_lessthan(t5, t3, 10U, t2, 10U);
    if (t6 == 1)
        goto LAB5;

LAB6:    t8 = (t0 + 2472U);
    t9 = *((char **)t8);
    t8 = (t0 + 3368795);
    t11 = ((IEEE_P_2592010699) + 4024);
    t12 = xsi_vhdl_greater(t11, t9, 10U, t8, 10U);
    if (t12 == 1)
        goto LAB8;

LAB9:    t7 = (unsigned char)0;

LAB10:    t1 = t7;

LAB7:    if (t1 != 0)
        goto LAB2;

LAB4:    xsi_set_current_line(55, ng0);
    t2 = (t0 + 5704);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t8 = *((char **)t5);
    *((unsigned char *)t8) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);

LAB3:    xsi_set_current_line(58, ng0);
    t2 = (t0 + 2632U);
    t3 = *((char **)t2);
    t2 = (t0 + 3368815);
    t5 = ((IEEE_P_2592010699) + 4024);
    t6 = xsi_vhdl_lessthan(t5, t3, 10U, t2, 10U);
    if (t6 == 1)
        goto LAB14;

LAB15:    t8 = (t0 + 3368825);
    t10 = (t0 + 2632U);
    t11 = *((char **)t10);
    t10 = ((IEEE_P_2592010699) + 4024);
    t12 = xsi_vhdl_lessthan(t10, t8, 9U, t11, 10U);
    if (t12 == 1)
        goto LAB17;

LAB18:    t7 = (unsigned char)0;

LAB19:    t1 = t7;

LAB16:    if (t1 != 0)
        goto LAB11;

LAB13:    xsi_set_current_line(61, ng0);
    t2 = (t0 + 5768);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t8 = *((char **)t5);
    *((unsigned char *)t8) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);

LAB12:    xsi_set_current_line(69, ng0);
    t2 = (t0 + 3368844);
    t4 = (t0 + 5832);
    t5 = (t4 + 56U);
    t8 = *((char **)t5);
    t9 = (t8 + 56U);
    t10 = *((char **)t9);
    memcpy(t10, t2, 8U);
    xsi_driver_first_trans_fast(t4);
    t2 = (t0 + 5384);
    *((int *)t2) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(53, ng0);
    t18 = (t0 + 5704);
    t19 = (t18 + 56U);
    t20 = *((char **)t19);
    t21 = (t20 + 56U);
    t22 = *((char **)t21);
    *((unsigned char *)t22) = (unsigned char)2;
    xsi_driver_first_trans_fast(t18);
    goto LAB3;

LAB5:    t1 = (unsigned char)1;
    goto LAB7;

LAB8:    t13 = (t0 + 2472U);
    t14 = *((char **)t13);
    t13 = (t0 + 3368805);
    t16 = ((IEEE_P_2592010699) + 4024);
    t17 = xsi_vhdl_lessthan(t16, t14, 10U, t13, 10U);
    t7 = t17;
    goto LAB10;

LAB11:    xsi_set_current_line(59, ng0);
    t18 = (t0 + 5768);
    t19 = (t18 + 56U);
    t20 = *((char **)t19);
    t21 = (t20 + 56U);
    t22 = *((char **)t21);
    *((unsigned char *)t22) = (unsigned char)2;
    xsi_driver_first_trans_fast(t18);
    goto LAB12;

LAB14:    t1 = (unsigned char)1;
    goto LAB16;

LAB17:    t13 = (t0 + 2632U);
    t14 = *((char **)t13);
    t13 = (t0 + 3368834);
    t16 = ((IEEE_P_2592010699) + 4024);
    t17 = xsi_vhdl_lessthan(t16, t14, 10U, t13, 10U);
    t7 = t17;
    goto LAB19;

}

static void work_a_0197255140_3212880686_p_3(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;

LAB0:    xsi_set_current_line(74, ng0);

LAB3:    t1 = (t0 + 2152U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 5896);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = t3;
    xsi_driver_first_trans_fast_port(t1);

LAB2:    t8 = (t0 + 5400);
    *((int *)t8) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_0197255140_3212880686_p_4(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;

LAB0:    xsi_set_current_line(75, ng0);

LAB3:    t1 = (t0 + 2312U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 5960);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = t3;
    xsi_driver_first_trans_fast_port(t1);

LAB2:    t8 = (t0 + 5416);
    *((int *)t8) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_0197255140_3212880686_p_5(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;

LAB0:    xsi_set_current_line(77, ng0);

LAB3:    t1 = (t0 + 1992U);
    t2 = *((char **)t1);
    t1 = (t0 + 6024);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    memcpy(t6, t2, 8U);
    xsi_driver_first_trans_fast_port(t1);

LAB2:    t7 = (t0 + 5432);
    *((int *)t7) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}


extern void work_a_0197255140_3212880686_init()
{
	static char *pe[] = {(void *)work_a_0197255140_3212880686_p_0,(void *)work_a_0197255140_3212880686_p_1,(void *)work_a_0197255140_3212880686_p_2,(void *)work_a_0197255140_3212880686_p_3,(void *)work_a_0197255140_3212880686_p_4,(void *)work_a_0197255140_3212880686_p_5};
	xsi_register_didat("work_a_0197255140_3212880686", "isim/scrn_tb_isim_beh.exe.sim/work/a_0197255140_3212880686.didat");
	xsi_register_executes(pe);
}
