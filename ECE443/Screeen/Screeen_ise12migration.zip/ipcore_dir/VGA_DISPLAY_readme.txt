The following files were generated for 'VGA_DISPLAY' in directory
F:\ECE.CLASSES\ECE 443\Screeen\ipcore_dir\

XCO file generator:
   Generate an XCO file for compatibility with legacy flows.

   * VGA_DISPLAY.xco

Creates an implementation netlist:
   Creates an implementation netlist for the IP.

   * VGA_DISPLAY/drivers/osd_v1_03_a/data/osd_v2_1_0.mdd
   * VGA_DISPLAY/drivers/osd_v1_03_a/data/osd_v2_1_0.tcl
   * VGA_DISPLAY/drivers/osd_v1_03_a/doc/html/api/annotated.html
   * VGA_DISPLAY/drivers/osd_v1_03_a/doc/html/api/classes.html
   * VGA_DISPLAY/drivers/osd_v1_03_a/doc/html/api/closed.gif
   * VGA_DISPLAY/drivers/osd_v1_03_a/doc/html/api/files.html
   * VGA_DISPLAY/drivers/osd_v1_03_a/doc/html/api/functions.html
   * VGA_DISPLAY/drivers/osd_v1_03_a/doc/html/api/functions_vars.html
   * VGA_DISPLAY/drivers/osd_v1_03_a/doc/html/api/globals.html
   * VGA_DISPLAY/drivers/osd_v1_03_a/doc/html/api/globals_defs.html
   * VGA_DISPLAY/drivers/osd_v1_03_a/doc/html/api/globals_func.html
   * VGA_DISPLAY/drivers/osd_v1_03_a/doc/html/api/globals_type.html
   * VGA_DISPLAY/drivers/osd_v1_03_a/doc/html/api/globals_vars.html
   * VGA_DISPLAY/drivers/osd_v1_03_a/doc/html/api/index.html
   * VGA_DISPLAY/drivers/osd_v1_03_a/doc/html/api/open.gif
   * VGA_DISPLAY/drivers/osd_v1_03_a/doc/html/api/struct_x_o_s_d.html
   * VGA_DISPLAY/drivers/osd_v1_03_a/doc/html/api/struct_x_o_s_d___config.html
   * VGA_DISPLAY/drivers/osd_v1_03_a/doc/html/api/struct_x_o_s_d___layer.html
   * VGA_DISPLAY/drivers/osd_v1_03_a/doc/html/api/tab_b.gif
   * VGA_DISPLAY/drivers/osd_v1_03_a/doc/html/api/tab_l.gif
   * VGA_DISPLAY/drivers/osd_v1_03_a/doc/html/api/tab_r.gif
   * VGA_DISPLAY/drivers/osd_v1_03_a/doc/html/api/xosd_8c.html
   * VGA_DISPLAY/drivers/osd_v1_03_a/doc/html/api/xosd_8c_source.html
   * VGA_DISPLAY/drivers/osd_v1_03_a/doc/html/api/xosd_8h.html
   * VGA_DISPLAY/drivers/osd_v1_03_a/doc/html/api/xosd_8h_source.html
   * VGA_DISPLAY/drivers/osd_v1_03_a/doc/html/api/xosd__g_8c.html
   * VGA_DISPLAY/drivers/osd_v1_03_a/doc/html/api/xosd__g_8c_source.html
   * VGA_DISPLAY/drivers/osd_v1_03_a/doc/html/api/xosd__hw_8h.html
   * VGA_DISPLAY/drivers/osd_v1_03_a/doc/html/api/xosd__hw_8h_source.html
   * VGA_DISPLAY/drivers/osd_v1_03_a/doc/html/api/xosd__intr_8c.html
   * VGA_DISPLAY/drivers/osd_v1_03_a/doc/html/api/xosd__intr_8c_source.html
   * VGA_DISPLAY/drivers/osd_v1_03_a/doc/html/api/xosd__sinit_8c.html
   * VGA_DISPLAY/drivers/osd_v1_03_a/doc/html/api/xosd__sinit_8c_source.html
   * VGA_DISPLAY/drivers/osd_v1_03_a/example/example.c
   * VGA_DISPLAY/drivers/osd_v1_03_a/src/Makefile
   * VGA_DISPLAY/drivers/osd_v1_03_a/src/xosd.c
   * VGA_DISPLAY/drivers/osd_v1_03_a/src/xosd.h
   * VGA_DISPLAY/drivers/osd_v1_03_a/src/xosd_g.c
   * VGA_DISPLAY/drivers/osd_v1_03_a/src/xosd_hw.h
   * VGA_DISPLAY/drivers/osd_v1_03_a/src/xosd_intr.c
   * VGA_DISPLAY/drivers/osd_v1_03_a/src/xosd_sinit.c
   * VGA_DISPLAY/pcores/axi_osd_v3_00_a/data/axi_osd_v2_1_0.mpd
   * VGA_DISPLAY/pcores/axi_osd_v3_00_a/data/axi_osd_v2_1_0.mui
   * VGA_DISPLAY/pcores/axi_osd_v3_00_a/data/axi_osd_v2_1_0.pao
   * VGA_DISPLAY/pcores/axi_osd_v3_00_a/data/axi_osd_v2_1_0.tcl
   * VGA_DISPLAY/pcores/axi_osd_v3_00_a/hdl/vhdl/HWT.vhd
   * VGA_DISPLAY/pcores/axi_osd_v3_00_a/hdl/vhdl/MemXLib_arch.vhd
   * VGA_DISPLAY/pcores/axi_osd_v3_00_a/hdl/vhdl/MemXLib_utils.vhd
   * VGA_DISPLAY/pcores/axi_osd_v3_00_a/hdl/vhdl/alpha_blend_ctrl.vhd
   * VGA_DISPLAY/pcores/axi_osd_v3_00_a/hdl/vhdl/alpha_blend_elem.vhd
   * VGA_DISPLAY/pcores/axi_osd_v3_00_a/hdl/vhdl/axi_osd.vhd
   * VGA_DISPLAY/pcores/axi_osd_v3_00_a/hdl/vhdl/axis_input_buffer.vhd
   * VGA_DISPLAY/pcores/axi_osd_v3_00_a/hdl/vhdl/axis_output_buffer.vhd
   * VGA_DISPLAY/pcores/axi_osd_v3_00_a/hdl/vhdl/mult_add_pipeline.vhd
   * VGA_DISPLAY/pcores/axi_osd_v3_00_a/hdl/vhdl/mux_tree.vhd
   * VGA_DISPLAY/pcores/axi_osd_v3_00_a/hdl/vhdl/osd_backbone.vhd
   * VGA_DISPLAY/pcores/axi_osd_v3_00_a/hdl/vhdl/osd_counters.vhd
   * VGA_DISPLAY/pcores/axi_osd_v3_00_a/hdl/vhdl/osd_meminit_pkg.vhd
   * VGA_DISPLAY/pcores/axi_osd_v3_00_a/hdl/vhdl/osd_package.vhd
   * VGA_DISPLAY/pcores/axi_osd_v3_00_a/hdl/vhdl/osd_priority_mux.vhd
   * VGA_DISPLAY/pcores/axi_osd_v3_00_a/hdl/vhdl/osd_priority_select.vhd
   * VGA_DISPLAY/pcores/axi_osd_v3_00_a/hdl/vhdl/osd_rt_gpu2.vhd
   * VGA_DISPLAY/pcores/axi_osd_v3_00_a/hdl/vhdl/user_logic.vhd
   * VGA_DISPLAY/pcores/axi_osd_v3_00_a/hdl/vhdl/version_reg.vhd

IP Symbol Generator:
   Generate an IP symbol based on the current project options'.

   * VGA_DISPLAY.asy

SYM file generator:
   Generate a SYM file for compatibility with legacy flows

   * VGA_DISPLAY.sym

Generate ISE metadata:
   Create a metadata file for use when including this core in ISE designs

   * VGA_DISPLAY_xmdf.tcl

Generate ISE subproject:
   Create an ISE subproject for use when including this core in ISE designs

   * VGA_DISPLAY.gise
   * VGA_DISPLAY.xise

Deliver Readme:
   Readme file for the IP.

   * VGA_DISPLAY_readme.txt

Generate FLIST file:
   Text file listing all of the output files produced when a customized core was
   generated in the CORE Generator.

   * VGA_DISPLAY_flist.txt

Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

