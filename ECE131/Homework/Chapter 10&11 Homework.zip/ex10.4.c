#include <stdio.h>

void substring (char source[], int start, int count, char result[]);

int main (void)
{
    int start, count;
    char buffer[81];
    char result[81];
    char source[81];
    void readLine (char buffer[]);

    printf ("Enter string: ");

    readLine (source);

    printf ("Enter start index: ");

    scanf ("%i", &start);

    printf ("Enter count: ");

    scanf ("%i", &count);

    substring ( source, start, count, result );

    printf ("Result: %s\n", result);

    return 0;
}

void substring (char source[], int start, int count, char result[])

{
    int i, k;

    k = 0;   

    for ( i = start; i < start + count; ++i ){
        result[k] = source[i];
        ++k;
        if ( result[k] == '\0' )
            break;

    }

    result[k] = 0;

}

void readLine (char buffer[])
{
    char character;
    int z = 0;

    do 
    {
        character = getchar ();
        buffer[z] = character;
        ++z;
    }
    while ( character != '\n' );

    buffer[z - 1] = '\0';
}


