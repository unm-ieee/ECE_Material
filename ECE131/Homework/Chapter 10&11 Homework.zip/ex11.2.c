#include <stdio.h>

struct entry
{
    int value;
    struct entry *next;
};

void insertEntry (struct entry *newEnt, struct entry *n2 );

int main (void)
{

    struct entry n1, n2, n3, newEnt;
    int i;

    n1.value = 100;
    n2.value = 200;
    n3.value = 300;
    newEnt.value = 400;



    n1.next = &n2;
    n2.next = &n3;
    n3.next = NULL;

    i = n1.next->value;
    printf ("Before insertion: %i  ", i);

    printf ("%i\n", n2.next->value);

    insertEntry ( &newEnt, &n2 );

    printf ("After insertion: %i  ", i);
   
    printf ("%i\n", n2.next->value);

    return 0;
}

void insertEntry (struct entry *newEnt, struct entry *n2)
{

    newEnt->next = n2->next;
    n2->next = newEnt;

}
