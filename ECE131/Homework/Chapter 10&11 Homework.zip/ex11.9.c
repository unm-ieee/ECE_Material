#include <stdio.h>

int main (void)
{
    int   i;
    char  *pline;
    char  line[81];
    void  readLine (char  *buffer);

    pline = &line[0];

    for ( i = 0; i < 3; ++i )
    {
        readLine (pline);
        printf ("%s\n\n", line);
    }

    return 0;
}

void readLine (char  *buffer)
{
    char  character;
    int   i = 0;

    do 
    {
        character = getchar();
        *buffer = character;
        ++buffer;
    }
    while ( character != '\n' );
   
    --buffer;
}

