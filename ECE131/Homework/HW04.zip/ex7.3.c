#include <stdio.h>
int main (void)
{
    int ratingCounter[11], i, responce;

    for ( i = 1; i <= 10; ++i )
        ratingCounter[i] = 0;

    printf ("Enter yout responces(1 - 10), type 999 when you are finished.\n");

    for ( i = 1; i >= 1; ++i ){
        scanf("%i", &responce);


        if( responce < 1 || responce > 10 && responce < 998 )
            printf ("Bad responce.\n");

        if ( responce > 999 )
            printf ("Bad responce.\n");

        if ( responce == 999 ){
            printf ("Thank you.");
            break;
        }
        else 
            ++ratingCounter[responce];


    }

    printf ("\n\nRating    Number of responces\n");
    printf ("------    ------------------\n");

    for ( i = 1; i <= 10; ++i )
        printf ("%4i%14i\n", i, ratingCounter[i]);

    return 0;
}


