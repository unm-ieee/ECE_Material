#include <stdio.h>

int main (void)
{
    int i;
    float  num[10] = {5.56, 7.26, 30.06, .308, .22, .32, .357, .44, .45, .50};
    float avg = 0;

    for ( i = 0; i < 10; ++i )
        avg += num[i];

    printf ("The average of the numbers are: %.4g\n", avg / 10);

    return 0;
} 
