#include <stdio.h>

int x_to_the_n (int x, int n)
{  
    int i; 
    long int temp;


    temp = 1;
    for ( i = 1; i <= n; ++i )
        temp *= x;

    return temp; 
}
int main (void)
{
    int x, n; 
    int x_to_the_n (int x, int n);
    int temp;

    printf ("please enter 'integer^power': ");
    scanf ("%i^%i", &x, &n);


    temp = x_to_the_n (x, n);
    printf ("%i to the power of %i is %i\n", x, n, temp);

    return 0;
}


