#include <stdio.h>

float absoluteValue (float x)
{
    if ( x < 0 )
        x = -x;
    return x;
}

float squareRoot (float x, float epsilon)

{
    float guess = 1.0;

    while ( absoluteValue ( guess * guess - x ) >= epsilon )
        guess = ( x / guess + guess ) / 2.0;


    return guess;
}

int main (void)
{
    float x;

    printf ("Enter the number you'd like to be square rooted: \n");
    scanf ("%f", &x);

    printf ("The square root of %f is %f\n", x, squareRoot (x, .00001));


    return 0;
}
