/* Name:  < Ryan Fenn >  */
/* Date:  < 09/01/2011 > */
/* ECE 131, Homework #1  */

#include <stdio.h>
main()
{
    printf("\n\nQ. How many progammers does it take to change a light bulb?\nA. None - It's a hardware problem\n\n");
}
