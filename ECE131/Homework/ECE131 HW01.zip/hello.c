/* Name:  < Ryan Fenn >  */
/* Date:  < 09/01/2011 > */
/* ECE 131, Homework #1  */

#include <stdio.h>
main()
{
    printf("\n\n Hello world!\n\n");
}
