#include <stdio.h>
int main (void)
{
    double a = 3.31e-8;
    double b = 2.01e-7;
    double c = 7.16e-6; 
    double d = 2.01e-8;
    double sum1;
    double sum2;

    sum1 = a * b;
    sum2 = c + d;

    printf ("\n\n(3.31e-8 * 2.01e-7) / (7.16e-6 + 2.01e-8) = %e\n\n", sum1 / sum2);

    return 0;
}


