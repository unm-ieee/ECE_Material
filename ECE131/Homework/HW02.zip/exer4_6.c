#include <stdio.h>
#include <math.h> //Provided I'm allowed to use the math.h header file.
int main (void)
{
    //This program evaluates the polynomial when given x = 2.55
    double a;
    double b;
    
    a = 3 * pow(2.55,3);
    b = 5 * pow(2.55,2);

    printf ("\n\n3x^3 - 5x^2 + 6 = %g when x = 2.55\n\n", a + b + 6);

    return 0;
}

