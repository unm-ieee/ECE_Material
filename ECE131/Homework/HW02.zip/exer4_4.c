#include <stdio.h>
int main (void)
{

    int f = 27; // degrees Fahrenheit
    const int b = 32;
    const float c = 1.8;
    float result;

    result = (f - b) / c; //Celsius conversion formula 
    printf ("\n\n27 degrees Fahrenheit converts to %g degrees Celsius\n\n", result);

    return 0;
}
