#include <stdio.h>
#include <stdbool.h>

struct date
{
    int month;
    int day;
    int year;
};

struct time
{
    int hour;
    int min;
    int sec;
};

struct dateAndTime
{
    struct date  sdate;
    struct time  stime;
};

struct dateAndTime  clockKeeper (struct dateAndTime);
struct date  dateUpdate (struct date);
struct time timeUpdate (struct time);
int numberOfDays (struct date d);
bool isLeapYear  (struct date d);

int main (void)
{

    struct dateAndTime mdnt = { { .month = 2, .day = 1, .year = 2004 }, {.hour = 23, .min = 59, .sec = 59} };

    mdnt = clockKeeper (mdnt);

    printf ("%i:%i:%i:%i:%i:%i \n", mdnt.sdate.month, mdnt.sdate.day, mdnt.sdate.year, mdnt.stime.hour, mdnt.stime.min, mdnt.stime.sec);


    return 0;
}
struct date  dateUpdate (struct date tdate) //Function to calc tomorrow's date
{
    struct date  tomorrow;

    if ( tdate.day != numberOfDays (tdate) ) {
        tomorrow.day = tdate.day + 1;
        tomorrow.month = tdate.month;
        tomorrow.year = tdate.year;
    }
    else if ( tdate.month == 12 ) {  //end of year
        tomorrow.day = 1;
        tomorrow.month = 1;
        tomorrow.year = tdate.year + 1;
    }
    else {                          //end of month
        tomorrow.day = 1;
        tomorrow.month = tdate.month + 1;
        tomorrow.year = tdate.year;
    }

    return tomorrow;
}

int numberOfDays  (struct date d) //Function to find the number of days in a month
{
    int days;
    bool isLeapYear (struct date d);
    const int daysPerMonth[12] = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };

    if ( isLeapYear (d) == true  && d.month == 2)
        days = 29;
    else
        days = daysPerMonth[d.month - 1];

    return days;
}

bool  isLeapYear (struct date d) //Function to determin if it's a leap year
{
    bool leapYearFlag;

    struct date t;

    t = d;

    if ( (t.year % 4 == 0 && t.year % 100 != 0)  || t.year % 400 == 0 )
        leapYearFlag = true; //Is a leap year
    else 
        leapYearFlag = false; //Not a leap year

    return leapYearFlag;
}


struct time timeUpdate (struct time ttime)
{

    struct date tdate;

    ++ttime.sec;

    if ( ttime.sec == 60 ){ //next minute
        ttime.sec = 0;
        ++ttime.min;
    }

    if (ttime.min == 60 ){ //next hour
        ttime.min = 0;
        ++ttime.hour;
    }

    if (ttime.hour == 24 ) //next day
        ttime.hour = 0;

    return ttime;
}
struct dateAndTime  clockKeeper (struct dateAndTime tdnt)
{
    struct date tdate;

    tdnt.stime = timeUpdate (tdnt.stime);

    if ( tdnt.stime.hour == 0 )
        tdnt.sdate = dateUpdate (tdnt.sdate);

    return tdnt;
}


