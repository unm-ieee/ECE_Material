#include <stdio.h>

typedef struct {
    int hour;
    int min;
    int sec;
} time;

time elapsed_time ( time  time1, time  time2);//This func calculates elapsed time 

int main (void)
{

    time  time1 = {time1.hour = 3, time1.min = 45, time1.sec = 15};
    time  time2 = {time2.hour = 9, time2.min = 44, time2.sec = 3};
    time  e_time;
    e_time = elapsed_time (time1, time2);


    printf ("Total elapsed time from 03:45:15 to 09:44:03 is: %i:%i:%i\n",e_time.hour, e_time.min, e_time.sec);

    return 0;
}

time  elapsed_time ( time  time1, time  time2)
{
    time  t_time;
    int tsec1, tsec2, dtime;

    if ( time1.hour > time2.hour ) //This if statement is used incase of midnight rollover
        time2.hour = time2.hour + 24; 

    tsec1 = time1.hour * 3600 + time1.min * 60 + time1.sec;//Converts total time to seconds
    tsec2 = time2.hour * 3600 + time2.min * 60 + time2.sec;
    dtime = tsec2 - tsec1;

    t_time.hour = dtime / 3600;//Determins the hours elapsed
    t_time.min = (dtime - t_time.hour * 3600) / 60;//Determins the minutes elapsed
    t_time.sec = dtime - (t_time.hour * 3600 + t_time.min * 60);//Dertemins the seconds 

    return t_time;
}

