#include  <stdio.h>
int main (void)
{
    int c, i, k, n, m, g, j, p;

    printf ("Enter your numbers: ");
    scanf ("%i", &c);


    if ( c == 0 )
    {
        printf ("zero\n");
        return 0;
    }

    n = c;
    m = 0; // Num characters read
    
    while ( n > 0 )// while statement figuers out the number of digits entered
    {    
        n = n / 10;
        m += 1;
    }

    g = m; // g is the current most significant digit
    
    for ( j = 1; j <= m; ++j )  // loop for the number of digits entered
    {  
        p = 10; // p = order of magnitude of the current digit
       
        for ( k = 1; k < g - 1; ++k ) //inner loop for power of 10
        {  
            p = p * 10;
        }     

        if ( g == 1)
            n = c; // n = value of current most significant digit
         else
           n = c / p;
          
         switch (n)
        {
          case 1:
          printf ("one ");
          break;
          case 2:
          printf ("two ");
          break;
          case 3:
          printf ("three ");
          break;
          case 4:
          printf ("four ");
          break;
          case 5:
          printf ("five ");
          break;
          case 6:
          printf ("six ");
          break;
          case 7:
          printf ("seven ");
          break;
          case 8:
          printf ("eight ");
          break;
          case 9:
          printf ("nine ");
          break;
          case 0:
          printf ("zero ");
          break;
          default:
          printf ("no!");

        }
        
        c = c % p;
        g = g - 1;
    }  
    printf ("\n");
    return 0;
}


