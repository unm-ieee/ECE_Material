#include <stdio.h>
int main (void)
{
    int number, right_digit;
    char c = '-';
    
    printf ("Enter your number: ");
    scanf ("%i", &number);

    if ( number <0 )
      
    do {
        right_digit = number % -10;
        printf ("%i", -right_digit);
        number = -number / -10;
       } 
       while ( number != 0 ); 


    if ( number >=1 )

    do {
        right_digit = number % 10;
        printf ("%i", right_digit);
        number = number / 10;
       }
       while ( number != 0 );

    else 
        printf ("%c", c);
     
    printf ("\n");

    return 0;
}
