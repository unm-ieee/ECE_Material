//Write a program to generate and display a table of n and n^2, for interger val    -use of  n ranging from 1 to 10.
#include <stdio.h>
int main (void)
{
    int n, npow2;

    printf ("\nTABLE OF N AND N^2\n\n");
    printf (" N       N^2\n");
    printf ("---     -----\n");

    npow2 = 0;

    for ( n = 1; n <= 10;  ++n )
    {
        npow2 = n * n;
        printf (" %2i        %i\n", n, npow2);
    }

    return 0;
}
