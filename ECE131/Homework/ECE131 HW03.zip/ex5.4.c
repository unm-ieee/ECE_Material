// Program to generate and print a table of first 10 factorials.
#include <stdio.h>
int main (void)
{
    int z, zfac;
    
    printf ("\n TABLE OF FIRST 10 FACTORALS\n\n");
    printf (" Z         Z!\n");
    printf ("---       ----\n");

    zfac = 1;


    for ( z = 1; z <= 10; z++ )
    {
        zfac = zfac * z;
        printf (" %2i         %i\n", z, zfac);
    }

   return 0;
} 
