#include <stdio.h>
int main (void)
{
    int value1, value2;
    double sum;

    printf ("Enter your two numbers in set notation: ");
    scanf ("(%i,%i)", &value1, &value2);

    sum = (double) value1 / value2;
    
    if ( value2 == 0 )     
        printf ("Warning, dividing by zero may cause the universe to implode!\n"); 
        
    else
        printf ("The Quotient of your numbers is %.3g\n", sum);

    return 0;
}
