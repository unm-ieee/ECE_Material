/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x79f3f3a8 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "G:/encoder.vhdl";



static void work_a_1881823395_3950995093_p_0(char *t0)
{
    char *t1;
    char *t2;
    int t3;
    unsigned int t4;
    unsigned int t5;
    unsigned int t6;
    unsigned char t7;
    unsigned char t8;
    char *t9;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    char *t17;
    int t18;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    unsigned char t22;
    unsigned char t23;
    char *t24;
    char *t26;
    char *t27;
    char *t28;
    char *t29;
    char *t30;
    char *t31;
    char *t32;
    int t33;
    unsigned int t34;
    unsigned int t35;
    unsigned int t36;
    unsigned char t37;
    unsigned char t38;
    char *t39;
    char *t41;
    char *t42;
    char *t43;
    char *t44;
    char *t45;
    char *t46;
    char *t47;
    int t48;
    unsigned int t49;
    unsigned int t50;
    unsigned int t51;
    unsigned char t52;
    unsigned char t53;
    char *t54;
    char *t56;
    char *t57;
    char *t58;
    char *t59;
    char *t60;
    char *t61;
    char *t62;
    int t63;
    unsigned int t64;
    unsigned int t65;
    unsigned int t66;
    unsigned char t67;
    unsigned char t68;
    char *t69;
    char *t71;
    char *t72;
    char *t73;
    char *t74;
    char *t75;
    char *t76;
    char *t77;
    int t78;
    unsigned int t79;
    unsigned int t80;
    unsigned int t81;
    unsigned char t82;
    unsigned char t83;
    char *t84;
    char *t86;
    char *t87;
    char *t88;
    char *t89;
    char *t90;
    char *t91;
    char *t92;
    int t93;
    unsigned int t94;
    unsigned int t95;
    unsigned int t96;
    unsigned char t97;
    unsigned char t98;
    char *t99;
    char *t101;
    char *t102;
    char *t103;
    char *t104;
    char *t105;
    char *t106;
    char *t108;
    char *t109;
    char *t110;
    char *t111;
    char *t112;
    char *t113;

LAB0:    xsi_set_current_line(13, ng0);
    t1 = (t0 + 592U);
    t2 = *((char **)t1);
    t3 = (7 - 7);
    t4 = (t3 * -1);
    t5 = (1U * t4);
    t6 = (0 + t5);
    t1 = (t2 + t6);
    t7 = *((unsigned char *)t1);
    t8 = (t7 == (unsigned char)3);
    if (t8 != 0)
        goto LAB3;

LAB4:    t16 = (t0 + 592U);
    t17 = *((char **)t16);
    t18 = (6 - 7);
    t19 = (t18 * -1);
    t20 = (1U * t19);
    t21 = (0 + t20);
    t16 = (t17 + t21);
    t22 = *((unsigned char *)t16);
    t23 = (t22 == (unsigned char)3);
    if (t23 != 0)
        goto LAB5;

LAB6:    t31 = (t0 + 592U);
    t32 = *((char **)t31);
    t33 = (5 - 7);
    t34 = (t33 * -1);
    t35 = (1U * t34);
    t36 = (0 + t35);
    t31 = (t32 + t36);
    t37 = *((unsigned char *)t31);
    t38 = (t37 == (unsigned char)3);
    if (t38 != 0)
        goto LAB7;

LAB8:    t46 = (t0 + 592U);
    t47 = *((char **)t46);
    t48 = (4 - 7);
    t49 = (t48 * -1);
    t50 = (1U * t49);
    t51 = (0 + t50);
    t46 = (t47 + t51);
    t52 = *((unsigned char *)t46);
    t53 = (t52 == (unsigned char)3);
    if (t53 != 0)
        goto LAB9;

LAB10:    t61 = (t0 + 592U);
    t62 = *((char **)t61);
    t63 = (3 - 7);
    t64 = (t63 * -1);
    t65 = (1U * t64);
    t66 = (0 + t65);
    t61 = (t62 + t66);
    t67 = *((unsigned char *)t61);
    t68 = (t67 == (unsigned char)3);
    if (t68 != 0)
        goto LAB11;

LAB12:    t76 = (t0 + 592U);
    t77 = *((char **)t76);
    t78 = (2 - 7);
    t79 = (t78 * -1);
    t80 = (1U * t79);
    t81 = (0 + t80);
    t76 = (t77 + t81);
    t82 = *((unsigned char *)t76);
    t83 = (t82 == (unsigned char)3);
    if (t83 != 0)
        goto LAB13;

LAB14:    t91 = (t0 + 592U);
    t92 = *((char **)t91);
    t93 = (1 - 7);
    t94 = (t93 * -1);
    t95 = (1U * t94);
    t96 = (0 + t95);
    t91 = (t92 + t96);
    t97 = *((unsigned char *)t91);
    t98 = (t97 == (unsigned char)3);
    if (t98 != 0)
        goto LAB15;

LAB16:
LAB17:    t106 = (t0 + 2529);
    t108 = (t0 + 1584);
    t109 = (t108 + 32U);
    t110 = *((char **)t109);
    t111 = (t110 + 40U);
    t112 = *((char **)t111);
    memcpy(t112, t106, 3U);
    xsi_driver_first_trans_fast_port(t108);

LAB2:    t113 = (t0 + 1540);
    *((int *)t113) = 1;

LAB1:    return;
LAB3:    t9 = (t0 + 2508);
    t11 = (t0 + 1584);
    t12 = (t11 + 32U);
    t13 = *((char **)t12);
    t14 = (t13 + 40U);
    t15 = *((char **)t14);
    memcpy(t15, t9, 3U);
    xsi_driver_first_trans_fast_port(t11);
    goto LAB2;

LAB5:    t24 = (t0 + 2511);
    t26 = (t0 + 1584);
    t27 = (t26 + 32U);
    t28 = *((char **)t27);
    t29 = (t28 + 40U);
    t30 = *((char **)t29);
    memcpy(t30, t24, 3U);
    xsi_driver_first_trans_fast_port(t26);
    goto LAB2;

LAB7:    t39 = (t0 + 2514);
    t41 = (t0 + 1584);
    t42 = (t41 + 32U);
    t43 = *((char **)t42);
    t44 = (t43 + 40U);
    t45 = *((char **)t44);
    memcpy(t45, t39, 3U);
    xsi_driver_first_trans_fast_port(t41);
    goto LAB2;

LAB9:    t54 = (t0 + 2517);
    t56 = (t0 + 1584);
    t57 = (t56 + 32U);
    t58 = *((char **)t57);
    t59 = (t58 + 40U);
    t60 = *((char **)t59);
    memcpy(t60, t54, 3U);
    xsi_driver_first_trans_fast_port(t56);
    goto LAB2;

LAB11:    t69 = (t0 + 2520);
    t71 = (t0 + 1584);
    t72 = (t71 + 32U);
    t73 = *((char **)t72);
    t74 = (t73 + 40U);
    t75 = *((char **)t74);
    memcpy(t75, t69, 3U);
    xsi_driver_first_trans_fast_port(t71);
    goto LAB2;

LAB13:    t84 = (t0 + 2523);
    t86 = (t0 + 1584);
    t87 = (t86 + 32U);
    t88 = *((char **)t87);
    t89 = (t88 + 40U);
    t90 = *((char **)t89);
    memcpy(t90, t84, 3U);
    xsi_driver_first_trans_fast_port(t86);
    goto LAB2;

LAB15:    t99 = (t0 + 2526);
    t101 = (t0 + 1584);
    t102 = (t101 + 32U);
    t103 = *((char **)t102);
    t104 = (t103 + 40U);
    t105 = *((char **)t104);
    memcpy(t105, t99, 3U);
    xsi_driver_first_trans_fast_port(t101);
    goto LAB2;

LAB18:    goto LAB2;

}


extern void work_a_1881823395_3950995093_init()
{
	static char *pe[] = {(void *)work_a_1881823395_3950995093_p_0};
	xsi_register_didat("work_a_1881823395_3950995093", "isim/Lab5Test_isim_beh.exe.sim/work/a_1881823395_3950995093.didat");
	xsi_register_executes(pe);
}
